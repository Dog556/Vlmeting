<!-- 主页引导文件 -->
<?php
require './views/index.html';