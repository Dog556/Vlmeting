<?php

// 数据库文件路径
$dbPath = '../uploads/674c925b3d92a.db'; // 请替换为你的数据库文件的实际路径

// 确定每页显示的数据条数
$perPage = 10;

// 检查是否有页码参数，如果没有则默认为第一页
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// 检查是否有查询参数
$query = isset($_GET['query']) ? $_GET['query'] : '';

// 创建 PDO 实例
$db = new PDO('sqlite:' . $dbPath);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 准备 SQL 查询
if ($query) {
    // 如果存在查询参数，执行模糊查询
    $searchQuery = "%" . $query . "%";
    $query = "SELECT title, up_time, msg, url FROM vulnerabilities WHERE title LIKE ? OR msg LIKE ? ORDER BY up_time DESC LIMIT :perPage OFFSET :offset";
    $stmt = $db->prepare($query);
    $stmt->bindParam(1, $searchQuery);
    $stmt->bindParam(2, $searchQuery);
} else {
    // 如果没有查询参数，查询所有数据
    $query = "SELECT title, up_time, msg, url FROM vulnerabilities ORDER BY up_time DESC LIMIT :perPage OFFSET :offset";
    $stmt = $db->prepare($query);
}

// 计算偏移量
$offset = ($page - 1) * $perPage;
$stmt->bindParam(':perPage', $perPage, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);

// 执行查询
$stmt->execute();

// 获取查询结果
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 格式化时间
foreach ($results as $key => $row) {
    $results[$key]['up_time'] = date('Y-m-d H:i:s', strtotime($row['up_time']));
}

// 以 JSON 格式输出结果
echo json_encode($results);