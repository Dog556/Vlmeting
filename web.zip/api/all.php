<?php

// 数据库文件路径
$dbPath = './uploads/674c925b3d92a.db';

// 创建 PDO 实例
try {
    $db = new PDO('sqlite:' . $dbPath);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 准备 SQL 查询，统计表中的记录数
    $query = "SELECT COUNT(*) AS total FROM vulnerabilities"; // 替换 your_table_name 为你的表名

    // 执行查询
    $stmt = $db->query($query);

    // 获取查询结果
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    // 输出结果
    echo $result['total'];

} catch (PDOException $e) {
    echo "数据库连接失败：" . $e->getMessage();
}