<?php
$allowedExtensions = ['db'];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    if ($file['error'] === UPLOAD_ERR_OK) {
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (in_array($extension, $allowedExtensions)) {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            // 固定文件名为 674c925b3d92a.db，这个名字要自己改
            $newFileName = '674c925b3d92a.db';
            $targetFile = $uploadDir . $newFileName;
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                $response = [
                    'status' => 'success',
                    'message' => '文件上传成功',
                    'path' => $targetFile
                ];
            } else {
                $response = [
                    'status' => 'error',
                    'message' => '文件上传失败，请重试。'
                ];
            }
        } else {
            $response = [
                'status' => 'error',
                'message' => '不支持的文件类型。'
            ];
        }
    } else {
        $response = [
            'status' => 'error',
            'message' => '文件上传出错，请重试。'
        ];
    }
} else {
    $response = [
        'status' => 'error',
        'message' => '无效的请求。'
    ];
}

// 设置响应头为 JSON
header('Content-Type: application/json');

// 输出 JSON 格式的响应
echo json_encode($response);