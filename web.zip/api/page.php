<?php

// 数据库文件路径
$dbPath = '../uploads/674c925b3d92a.db'; // 请替换为你的数据库文件的实际路径

// 创建 PDO 实例
$db = new PDO('sqlite:' . $dbPath);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 准备 SQL 查询，统计表中的记录数
$query = "SELECT COUNT(*) AS count FROM vulnerabilities"; // 替换 your_table_name 为你的表名

// 执行查询
$stmt = $db->query($query);

// 获取查询结果
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// 获取总数据条数
$totalItems = $result['count'];

// 以 JSON 格式输出结果
echo json_encode(['count' => $totalItems]);